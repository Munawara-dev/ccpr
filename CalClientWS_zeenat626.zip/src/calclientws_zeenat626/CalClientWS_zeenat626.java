/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calclientws_zeenat626;

/**
 *
 * @author zeena
 */
public class CalClientWS_zeenat626 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        try 
        {
            int a =10;
            int b =5;
            double r1 = add(a,b);
            double r2 = sub(a,b);
            double r3 = multi(a,b);
            double r4 = div(a,b); 
            
            System.out.println("Addition =" + r1);
            System.out.println("Subtraction =" + r2);
            System.out.println("Multiplication =" + r3);
            System.out.println("Division =" + r4);
        }
        catch (Exception e) 
        {
            System.out.println("Error: "+e);
        }
    }

    private static double add(int n1, int n2) {
        mypackage.CalculatorWSZeenat626_Service service = new mypackage.CalculatorWSZeenat626_Service();
        mypackage.CalculatorWSZeenat626 port = service.getCalculatorWSZeenat626Port();
        return port.add(n1, n2);
    }

    private static double div(int n1, int n2) {
        mypackage.CalculatorWSZeenat626_Service service = new mypackage.CalculatorWSZeenat626_Service();
        mypackage.CalculatorWSZeenat626 port = service.getCalculatorWSZeenat626Port();
        return port.div(n1, n2);
    }

    private static double multi(int n1, int n2) {
        mypackage.CalculatorWSZeenat626_Service service = new mypackage.CalculatorWSZeenat626_Service();
        mypackage.CalculatorWSZeenat626 port = service.getCalculatorWSZeenat626Port();
        return port.multi(n1, n2);
    }

    private static double sub(int n1, int n2) {
        mypackage.CalculatorWSZeenat626_Service service = new mypackage.CalculatorWSZeenat626_Service();
        mypackage.CalculatorWSZeenat626 port = service.getCalculatorWSZeenat626Port();
        return port.sub(n1, n2);
    }
    
    
}
