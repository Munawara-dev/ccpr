package factorialclientapp;

import java.math.BigInteger;

public class FactorialClientApp {

    public static void main(String[] args) {
        // Example usage: Calculate factorial of 5
        int number = 5;
        BigInteger result = calculateFactorial(number);
        System.out.println("Factorial of " + number + " is: " + result);
    }

    private static BigInteger calculateFactorial(int number) {
        try {
            mypac.FactorialWebService_Service service = new mypac.FactorialWebService_Service();
            mypac.FactorialWebService port = service.getFactorialWebServicePort();
            return port.calculateFactorial(number);
        } catch (Exception ex) {
            // Handle exceptions appropriately, e.g., logging or displaying an error message
            ex.printStackTrace();
            return BigInteger.valueOf(-1); // or throw exception
        }
    }
}
