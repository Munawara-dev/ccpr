/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poop;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author DELL
 */
@Embeddable
public class PlayersPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PLAYER_NAME")
    private String playerName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "AGE")
    private String age;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "RUNS")
    private String runs;

    public PlayersPK() {
    }

    public PlayersPK(String playerName, String age, String runs) {
        this.playerName = playerName;
        this.age = age;
        this.runs = runs;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getRuns() {
        return runs;
    }

    public void setRuns(String runs) {
        this.runs = runs;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (playerName != null ? playerName.hashCode() : 0);
        hash += (age != null ? age.hashCode() : 0);
        hash += (runs != null ? runs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PlayersPK)) {
            return false;
        }
        PlayersPK other = (PlayersPK) object;
        if ((this.playerName == null && other.playerName != null) || (this.playerName != null && !this.playerName.equals(other.playerName))) {
            return false;
        }
        if ((this.age == null && other.age != null) || (this.age != null && !this.age.equals(other.age))) {
            return false;
        }
        if ((this.runs == null && other.runs != null) || (this.runs != null && !this.runs.equals(other.runs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "poop.PlayersPK[ playerName=" + playerName + ", age=" + age + ", runs=" + runs + " ]";
    }
    
}
