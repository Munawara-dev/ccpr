/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poop;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author DELL
 */
@Entity
@Table(name = "PLAYERS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Players.findAll", query = "SELECT p FROM Players p")
    , @NamedQuery(name = "Players.findByPlayerName", query = "SELECT p FROM Players p WHERE p.playersPK.playerName = :playerName")
    , @NamedQuery(name = "Players.findByAge", query = "SELECT p FROM Players p WHERE p.playersPK.age = :age")
    , @NamedQuery(name = "Players.findByRuns", query = "SELECT p FROM Players p WHERE p.playersPK.runs = :runs")})
public class Players implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PlayersPK playersPK;

    public Players() {
    }

    public Players(PlayersPK playersPK) {
        this.playersPK = playersPK;
    }

    public Players(String playerName, String age, String runs) {
        this.playersPK = new PlayersPK(playerName, age, runs);
    }

    public PlayersPK getPlayersPK() {
        return playersPK;
    }

    public void setPlayersPK(PlayersPK playersPK) {
        this.playersPK = playersPK;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (playersPK != null ? playersPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Players)) {
            return false;
        }
        Players other = (Players) object;
        if ((this.playersPK == null && other.playersPK != null) || (this.playersPK != null && !this.playersPK.equals(other.playersPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "poop.Players[ playersPK=" + playersPK + " ]";
    }
    
}
