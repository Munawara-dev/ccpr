/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uploclient;

import mypac.StrinOPClient;

/**
 *
 * @author zeena
 */
public class UPLOClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        mypac.StrinOPClient client = new StrinOPClient();
        System.out.println(client.toUpperCaseMethod("zeenat"));
        System.out.println(client.toLowerCaseMethod("ZEENAT"));
    }
    
}
