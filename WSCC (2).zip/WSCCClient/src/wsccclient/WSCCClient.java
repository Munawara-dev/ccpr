/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsccclient;
import java.util.*;

/**
 *
 * @author zeena
 */
public class WSCCClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter your choice:");
        System.out.println("1->dollar to rupees");
        System.out.println("2->rupees to dollar");
        int option = sc.nextInt();
        
        System.out.println("Enter the amount Rs/Dollar):");
        int amt = sc.nextInt();
        
        if (option==1)
        {
          System.out.println("rupees to dollar:"+r2D(amt));        
        }
        else
        {
            System.out.println("dollar to rupees:"+d2R(amt));
        }
    }

        private static double d2R(double dollar) {
        mypac.WSCCu_Service service = new mypac.WSCCu_Service();
        mypac.WSCCu port = service.getWSCCuPort();
        return port.d2R(dollar);
    }

    private static double r2D(double rupees) {
        mypac.WSCCu_Service service = new mypac.WSCCu_Service();
        mypac.WSCCu port = service.getWSCCuPort();
        return port.r2D(rupees);
    }
    
}
