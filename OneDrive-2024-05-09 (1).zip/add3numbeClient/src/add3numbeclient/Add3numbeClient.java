package add3numbeclient;

import mypackage.AddService;
import mypackage.AdditionServicePortType;

public class Add3numbeClient {

    public static void main(String[] args) {
        try {
            // Create a new instance of the AddService
            AddService service = new AddService() {
                @Override
                public int addThreeNumbers(int num1, int num2, int num3) {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public AdditionServicePortType getAdditionServicePort() {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
            };

            // Get the port for the service
            AdditionServicePortType port = service.getAdditionServicePort();

            // Call the addThreeNumbers method on the port
            int result = port.Add3numbeClient(5, 10, 15);

            // Print the result
            System.out.println("Result: " + result);
        } catch (Exception e) {
            // Handle any exceptions
            e.printStackTrace();
        }
    }
}
