package addclient;

public class Addclient {

    public static void main(String[] args) {
        // Call the method to add three numbers
        int result = addThreeNumbers(5, 10, 15);
        
        // Print the result
        System.out.println("Result: " + result);
    }

    private static int addThreeNumbers(int num1, int num2, int num3) {
        // Create a client for the SOAP service
        mypac.AddService_Service service = new mypac.AddService_Service();
        mypac.AddService port = service.getAddServicePort();
        
        // Call the addThreeNumbers method of the service
        return port.addThreeNumbers(num1, num2, num3);
    }
}
