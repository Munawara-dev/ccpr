/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package add3numberclient;

/**
 *
 * @author zeena
 */
public class ClientApp {
    public static void main(String[] args) {
       addPackage.AdditionService service = new  addPackage AdditionService();
        com.myapp.service.AdditionServicePortType port = service.getAdditionServicePort();
        int result = port.addThreeNumbers(5, 10, 15);
        System.out.println("Result: " + result);
    }
}
